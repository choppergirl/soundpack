==============================================================================

    Choppergirl's Edgy Sound Pack "Read Me" Release Notes

    Made by the notorious Choppergirl of Team AirWar

    To download the latest version of this free software, go to:
      http://edgy.air-war.org
      http://soundpack.air-war.org
      or google "Choppergirl SoundPack"

    Read this file on a computer.  This Release Version: 2021.05.01
                                                                                                                                                           
            .--~*teu.        .n~~%x.       .--~*teu.          oe    
           dF     988Nx    x88X   888.    dF     988Nx      .@88    
          d888b   `8888>  X888X   8888L  d888b   `8888> ==*88888    
          ?8888>  98888F X8888X   88888  ?8888>  98888F    88888    
           "**"  x88888~ 88888X   88888X  "**"  x88888~    88888    
                d8888*`  88888X   88888X       d8888*`     88888    
              z8**"`   : 88888X   88888f     z8**"`   :    88888    
            :?.....  ..F 48888X   88888    :?.....  ..F    88888    
           <""888888888~  ?888X   8888"   <""888888888~    88888    
           8:  "888888*    "88X   88*`    8:  "888888*     88888    
           ""    "**"`       ^"==="`      ""    "**"`   '**%%%%%%** 
	   
            .n~~%x.       cuuu....uK        .n~~%x.           oe    
          x88X   888.     888888888       x88X   888.       .@88    
         X888X   8888L    8*888**"       X888X   8888L  ==*88888    
        X8888X   88888    >  .....      X8888X   88888     88888    
        88888X   88888X   Lz"  ^888Nu   88888X   88888X    88888    
        88888X   88888X   F     '8888k  88888X   88888X    88888    
        88888X   88888f   ..     88888> 88888X   88888f    88888    
        48888X   88888   @888L   88888  48888X   88888     88888    
         ?888X   8888"  '8888F   8888F   ?888X   8888"     88888    
          "88X   88*`    %8F"   d888"     "88X   88*`      88888    
            ^"==="`       ^"===*%"`         ^"==="`     '**%%%%%%**  
                                                          
                  Release Date Above is the Version Number

 ==============================================================================

				    @&%(*,.
                                    @@@&@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#
                                     .@@@
       .                            @@@@@@@                            .
                                    @@@@@@@
                  .                @@@@@@@@@                .
                     .@@@@@@@@@@@@ @@@@@@@@@&@@@@@@@@@@@@ .
                     @@@@@@@@@@@@@.@@@@@@@@@&@@@@@@@@@@@@@
                     @@      .,#@@@@@@@@@@@@@@@(..      @@
                     @&    @@@@@@@@    @@@@   @@@@@@@    @@
    @,               @&    @@@@@@@@ @@@ @@ @@@ @@@@@@    @@               @@
     @ ,*         #@@@@@@@ @@@@@@@@ @@@ @@ @@@@@@@@@@,@@@@@@@(         & .(
    @ &@@@@@@@@@@@@@@@@@@@@@.@@&@@@   @@@@ @@@@@@@@ @@@@@@@@@@@@@@@@@@@@@#.@
   @@@@@@@@@@@@@@@@@@@@@@@@@@@(@@@@ @@ @@@ @@@ @@@.@@@@@@@@@@@@@@@@@@@@@@@@@@@
 *@@@@@@@ &*(@ @@@@,@ @%*@@@@@@&/@@ @@@ @@@   @@.@@@@@@@ @%.@ @@@@ @.%@ @@@@@@@
 @@@@@@@@&    @@@@@.    @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@    (@@@@#    @@@@@@@@@
 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ *#,/@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
 @@@@@@@@@@@.        /@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*        *@@@@@@@@@@@
 @@@@@@@.   @@@@@@@@@/   @@@@@@@@@@@@/   &@@@@@@@@@@@#   %@@@@@@@@%   (@@@@@@@
/@@@@@,  @@@@@@@@@@@@@@@*  @@@@@@@@@@    .@@@@@@@@@%  &@@@@@@@@@@@@@@&  %@@@@@
%@@@@  .@@             &@@  @@%  /@@@@@@@@@@@   @@#  @@              @@  /@@@@
&@@@@  @@@ @@@ @@@%@@@@&@@#  @&&@/@@@@@@@@@@@ @ @@  @@@.@@@(@@@@(@@@ @@@  @@@@
@@@@@  @@@ @@@*@@@,@@@@&@@/  @&&@/@@@@@@@@@@@ @ @@  @@@.@@@&&@@&%@@@ @@@  @@@@
@@@@@   @@             &&@  @@&**(@@@@@@@@@@@*/*@@&  @@.             @@  &@@@@
@@@@@@%  @@@&##@@&#%%##@ . #%##@@%%%,.#@@ #&@##%#%@%  #&##%##@@&##@@@(  @@@@@@
&@@@@@@@&   /##@%####    &####%@####,.#%# &@%#%@##%%%#   .%##%%%##.   @@@@@@@@
#@@@@@@@@@@@%.     . %####%@@%#####%,.#@@ ####@@@#####@@@@.    .  &@@@@@@@@@@@
*@@@@@@@@@@@@,,,,,,,*@@@@@@@@@@@@@@@,     @@@@@@@@@@@@@@@@,,,,,,,,@@@@@@@@@@@@
 @@@@@@@@@@@@       .@@@@@@@@@@@@@@@(/////@@@@@@@@@@@@@@@@        @@@@@@@@@@@@
 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
 @@@@@@@@@@@@@@@@@@@@@@@@@                           @@@@@@@@@@@@@@@@@@@@@@@@@
 @@@@@@@@@     %@@@@@@@@@@   I create wealth and     @@@@@@@@@@.     @@@@@@@@@
 &@@@@@@@(    @@.  /@@@@@@  give it away for free    @@@@@@.  &@(    @@@@@@@@*
  @@@@@@@@    @@     @@@@@                           @@@@@     @@    @@@@@@@@
   @@@@@@@@@&*@@*/@@@@@@@@       Choppergirl         @@@@@@@%**@@*@@@@@@@@@@
    ,@@@@@@@@@@@@@@@@@@@@@                           @@@@@@@@@@@@@@@@@@@@@
       &@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@(
             ,&@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&.

   ___ _  __    OOOOO                                TTTTTTT XX    XX  ##
  /_  / )/__)  OO   OO pp pp     eee  nn nnn           TTT    XX  XX   ##
  /  (_// (    OO   OO ppp  pp ee   e nnn  nn   ___    TTT     XXXX    ##
               OO   OO pppppp  eeeee  nn   nn          TTT    XX  XX
                OOOO0  pp       eeeee nn   nn          TTT   XX    XX  ##
 Bad news..!           pp

  Amber doesn't love you. She's just using you, just like she's using 100,000
   other men she has wrapped around her little finger on 100,000 other TX's.

  Just say no to Amber. She's destroyed too many models, too many marriages!

  Don't get all distracted while flying by some studio polished femme fatale!
       She's a siren song waiting to lure your RC model to it's doom..


                                    Instead
                          You've got to stay... EDGY...
                    .&@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&.
                .@@@@@@@@@@@@@@@@@@@%#(((#%@@@@@@@@@@@@@@@@@@@
             ,@@@@@@@@@@@@&,                       *&@@@@@@@@@@@@.
           &@@@@@@@@@@/               /                 /@@@@@@@@@@%
         @@@@@@@@@@.                  &@@.                 .@@@@@@@@@@
       &@@@@@@@@*                    ,@@@@@#                  /@@@@@@@@%
     ,@@@@@@@@*                    @@@@@@@@@@@@@&               *@@@@@@@@,
    #@@@@@@@#                 (@@@@@@@@@@@@@@@@@@@@%              #@@@@@@@#
   %@@@@@@@                 &@@@@@@@@@@@@@@@@@@@@@@@@#             .@@@@@@@#
  (@@@@@@@               *@@@@@@@@@@@@@@@@@@@@@@@@@@@@@             .@@@@@@@(
 .@@@@@@@.            *@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@             ,@@@@@@@
 %@@@@@@%           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#             %@@@@@@%
 @@@@@@@.           @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@             ,@@@@@@@
 @@@@@@@            @@@@@@@@@@,  .#&@@@@@@@@@@@@@@@@@@@@@              @@@@@@@
 @@@@@@@              .(&&/          .@@@@@@@@@@@@@@@@@@%              @@@@@@@
 @@@@@@@.                          /@@@@@@@@@@@@@@@@@@@@.             ,@@@@@@@
 %@@@@@@%                        #@@@@@@@@@@@@@@@@@@@@@%              %@@@@@@%
 .@@@@@@@.                     *@@@@@@@@@@@@@@@@@@@@@@@              ,@@@@@@@
  (@@@@@@@                    &@@@@@@@@@@@@@@@@@@@@@@@              .@@@@@@@/
   #@@@@@@@.                 @@@@@@@@@@@@@@@@@@@@@@@@,             ,@@@@@@@#
    #@@@@@@@%               @@@@@@@@@@@@@@@@@@@@@@@@@             %@@@@@@@(
     ,@@@@@@@@*             @@@@@@@@@@@@@@@@@@@@@@@@            *@@@@@@@@.
       %@@@@@@@@(          /@@@@@@@@@@@@@@@@@@@@@@@@%,        (@@@@@@@@%
         @@@@@@@@@@.     %@@@@@@@@@@@@@@@@@@@@@@@@@@@@@(   .@@@@@@@@@&
           %@@@@@@@@@@(  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@(@@@@@@@@@@#
             .@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                 &@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                    .%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%.
                          * The Dark Horse of Airwar *
                                   Black Betty                   ��Trademark


       .__                          presents           .__       .__  _
  ____ |  |__   ____ ______ ______   ___________  ____ |__|______|  ||/ ______
_/ ___\|  |  \ /  _ \\____ \\____ \_/ __ \_  __ \/ ___\|  \_  __ \  |  /  ___/
\  \___|   Y  (  <_> )  |_> >  |_> >  ___/|  | \/ /_/  >  ||  | \/  |__\___ \
 \___  >___|__/\____/|   __/|   __/ \_____>__|  \___  /|__||__|  |____/____  >
     ||              |__|   |__|               /_____/                     ||
     ||                                                                    ||
     ||                 _______  ______   _______                          ||
     ||                (  ____ \(  __  \ (  ____ \|\     /|                ||
     ||_______|\       | (    \/| (  \  )| (    \/( \   / )                ||
     ()_______  )      | (__    | |   ) || |       \ (_) /                 ||
     ||       |/       |  __)   | |   | || | ____   \   /       /|_________||
     ||                | (      | |   ) || | \_  )   ) (       (  _________()
     ||                | (____/\| (__/  )| (___) |   | |        \|         ||
     ||                (_______/(______/ (_______)   \_/                   ||
     ||                                                                    ||
     ||         ____                        _ ____            _   _________||
     ||        / ___|  ___  _   _ _ __   __| |  _ \ __ _  ___| | / _________/
     ||        \___ \ / _ \| | | | '_ \ / _` | |_) / _` |/ __| |/ /
     ||____________) | (_) | |_| | | | | (_| |  __/ (_| | (__|   <
     \______________/ \___/ \__,_|_| |_|\__,_|_|   \__,_|\___|_|\_\


          Amber is so 2014, Rock a new girl on your radio in 2021!

 Brand New Sound Files for your Open-TX Transmitter SD Card from AIR-WAR.ORG !

 More files, in one tomboy voice - why have 4 different voices talking to you?

  Questions? Comments? Feedback? Bug reports? Sound file Requests? Hate mail?


                       Email:  choppergirl@air-war.org

                  RC & FPV Website:  http://fpv.air-war.org


                To find the latest version of this sound pack:

                             http://edgy.air-war.org

                             http://air-war.org/edgy


                                          ---------------+---------------
                                                    ___ /^^[___              _
                                                   /|^+----+   |#___________//
                                                 ( -+ |____|    ______-----+/
                                                  ==_________--'            \
                                                    ~_|___|__
  _____          __           __
 / ___/__  ___  / /____ ___  / /____
/ /__/ _ \/ _ \/ __/ -_) _ \/ __(_-<                                 ,,,
\___/\___/_//_/\__/\__/_//_/\__/___/                                (0 0)
 ================================================================ooO=(_)=Ooo===
 Sections in this Read Me:

 1. What this is and why you want it
 2. Where to install it
 3. How to use it
 4. Copyright Free License Blurb
 5. Sound File Recording Requests
 6. Future plans - the Edgy Cheeky Plus Pack?
 7. Who to contact with feedback/requests


                               \                                `::`
                                                                /
                                                               `    `;:`

                                  _ _
                                 (_\_)                   .;:;        /
                                (__<_{}                  ::;        `
                                 (_/_)                 _ ';:;;'
                                |\ |                   >'. ||  _
                                 \\| /|                `> \||.'<
                                  \|//                   `>|/ <`
                                   |/                     `||/`
                              ,.,.,|.,.,.              ^^^^^^^^^^^
 _      ____        __         ^`^`^`^`^`^
| | /| / / /  ___ _/ /_
| |/ |/ / _ \/ _ `/ __/
|__/|__/_//_/\_,_/\__/
 ==============================================================================
 1. == What this is and why you want it == == == == == ==

     This is a sound pack, or a directory of .wav files, to replace
     the "/SOUND/en" folder on the SD card of your Open-TX
     Transmitter.


     Why anybody would want this?  I found by installing other sound packs, 
     I ended up with three different girl voices on my radio... and I wanted 
     my radio to talk with just one consistent voice.  So I recorded 
     750 sounds to replace them all in one voice, which makes this the 
     largest and most comprehensive sound pack I know of to date.

     What makes my sound pack technically superior to all others besides having
     the most audio recordings of them all?  You can now see the contents 
     of audio files and sort by category from the Windows Explorer directory.

     Track Title is the audio file's contents; Album name is the Category 
     of Sound File.  No more guessing what's in a file.  You can sort in 
     ascending or descending order  by file name, track title, or album name 
     all from inside the Windows File directory

     http://air-war.org/graphics/edgy_dir_listing.jpg



     Key features:

     Drop in replacement for older sound packs, same file names.

     750+ sound files all in the same voice, not four different ones

     Conetents of files are now listed as Track Title in Windows
     Explorer - no more having to click on file to know what it says.

     You can browse audio files in Windows Explorer and sort by 
     File name, Title (phrase saying) or Album (category).  


     This version is just to establish a beachhead and get my 
     base files recorded and out there for feedback and usage.




     Possiblly... Coming soon!

     New sounds for Crossfire & Frsky Telemetry reporting 

     New sounds for Sims: MS Flight Sim, Realflight, Liftoff, DRL, 
     Velocidrone, etc.
     
     way more snarky sayings to keep you on your toes and 
'    personalize your transmitter with some cat-i-tude.



                                     '-.,;;:;,
                                      _;\;|\;:;,
                                     ) __ ' \;::,
                                 .--'  e   ':;;;:,           ;,
                                (^           ;;::;          ;;;,
                        _        --_.--.___,',:;::;     ,,,;:;;;,
                       < \        `;     |  ;:;;:;        ':;:;;;,,
                     <`-; \__     ,;    /    ';:;;:,       ';;;'
                     <`_   __',   ; ,  /    ::;;;:         //
                        `)|  \ \   ` .'      ';;:;,       //
                         `    \ `\  /        ;;:;;.      //__
                               \  `/`         ;:;  ~._,=~`   `~=,
                                \_|      (        ^     ^  ^ _^  \
                                  \    _,`      / ^ ^  ^   .' `.^ ;
                         <`-.      '-;`       /`  ^   ^  /\    ) ^/
                         <'- \__..-'` ___,,,-'._ ^  ^ _.'\^`'-' ^/
                          `)_   ..-''`          `~~~~`    `~===~`
                          <_.-`-._\
 _      ____
| | /| / / /  ___ _______
| |/ |/ / _ \/ -_) __/ -_)
|__/|__/_//_/\__/_/  \__/
 ==============================================================================
 2. == Where to install it == == == == ==

    Download the latest version of the sound pack from:

    http://edgy.air-war.org

    or

    http://downloads.air-war.org


    Unzip the archive to your desktop, you should
    find a folder called "SOUNDS/en" or just "en"


    To install it, all you have to do is unzip it and replace the /Sounds/en  
    folder on your radios SD card with my /Sounds/en folder.    

    You can rename your old folder to something else, delete it entirely, back 
    it up, or rename your old "en" folder to "cz" to play when you select 
    Czechslovakia (I think that might work, haven't tried it!)

    Note, it's about 25mb in size, so you will need that amount free on your 
    Radios SD card after you move or remove the old "en" folder.

    If it works, you should hear the transmitter say "Welcome to Open-TX" and 
    "Goodbye" in a new voice when you start/shutdown your radio.  

    Another good test is to add these lines to press your SYS button and tab 
    over to  Global Functions, and add these two lines, which should say 
    "The current time is" and then read out the time when you turn on your 
    radio (if all is working):

      GF1      ON      Play Track     timecu      1x
      GF2      ON      Play Value     Time        1x


    If your radio does not say "The current time is..." when you turn on 
    your radio after this, you've done something wrong, or do not have 
    your language preferences to English under SYS : Settings.


                                                                    /i
                                                                   //,
                                                                  ///i
                                                                ,/ ).'i
                                                                 |   )-i
                                                                 |   )i
                                                                 '   )i
                                                                /    |-
                                                           _.-./-.  /z_
                                                            `-. >._\ _ );i.
                                                             / `-'/`k-'`u)-'`
                                                            /    )-
                                                     ,.----'   ) '
                                                     /      )1`        fly
                                                    ///v`-v\v        on the
   __ __                                                         wings of love
  / // /__ _    __                                                5CymvTK9tLQ
 / _  / _ \ |/|/ /
/_//_/\___/__,__/
 ==============================================================================
 3. == How to use it == == == == ==


    The sounds in /SOUNDS/en/SYSTEM will automatically be used by the Open-TX
    operating system to read out values and numbers, report certain things,
    etc. and there is nothing further you need to do.

    However...

    All the other sounds in the /SOUNDS/en folder are there for you to
    call upon your transmitter to play and use at your discretion.

    You have to actually program and set up your transmitter to use them
    for any audio reporting you may desire.   You won't use all of them,
    just the ones you need to make your transmitter say what you want
    when certain switches are flipped or conditions are met.


    For example, on my TX-16s's named "Red Queen" and "Blue Caterpillar",
    my own SYS : Global Functions Table looks like this:
 

      GF1      ON      Play Track     timecu      1x
      GF2      ON      Play Value     Time        1x

      GF4      SA^     Play Track     off         No repeat	
      GF5      SA-     Play Track     buzzer      No repeat	
      GF6      SAv     Play Track     return      No repeat	

      GF8      SB^     Play Track     off         No repeat	
      GF9      SB-     Play Track     blkbox      No repeat	
      GF10     SBv     Play Track     turtle      No repeat	

      GF12     SC^     Play Track     off         No repeat	
      GF13     SC-     Play Track     batcap      No repeat	
      GF14     SC-     Play Value     TELE17      No repeat	
      GF15     SCv     Play Track     batcur      No repeat	
      GF16     SCv     Play value     TELE18      No repeat	

      GF18     SD^     Play Track     off         No repeat	
      GF19     SD-     Play Track     batper      No repeat	
      GF20     SD-     Play Value     TELE19      No repeat	
      GF21     SDv     Play Track     batvol      No repeat	
      GF22     SDv     Play value     TELE16      No repeat	

      GF24     SE^     Play Track     acro        No repeat	
      GF25     SE-     Play Track     hrzn        No repeat	
      GF26     SEv     Play Track     angl        No repeat

      GF28     SF^     Play Track     dosarm      No repeat	
      GF29     SFv     Play Track     arm         No repeat

      GF31     SG^     Play Track     off         No repeat	
      GF33     SG-     Play Track     alaron      No repeat	
      GF35     SGv     Play Track     trnon       No repeat

      GF37     SGv     Play Spimd     Beep 3      No repeat

      GF39     ON      Volume         S1          Checkmark ON
      GF40     ON      Backlight      S2          Checkmark ON

      GF52     ON      Play Track     ratepr      No repeat
      GF54     6P_1    Play Track     0001        No repeat
      GF55     6P_2    Play Track     0002        No repeat
      GF56     6P_3    Play Track     0003        No repeat
      GF57     6P_4    Play Track     0004        No repeat
      GF58     6P_5    Play Track     0005        No repeat
      GF59     6P_6    Play Track     0006        No repeat


      If you don't have a Crossfire or other module that supports
      telemetry installed, you won't see any TELE option available, 
      as those are telemetry values returned from the model.   
      You won't want to set up your radio identical to mine anyway,
      I'm just showing you mind here so you can get an idea of
      how things might be setup on a radio.

      Note that these assignments don't do any actual "function",
      you have to define that elsewhere... this is just where 
      I am defining which switch position will play what track
      when "entered into that position".

      The exception to "not doing anything" is GF39 & GF40 
      where I define the two POT knobs to control Volume and 
      Backlight level.   If you entered these lines and found 
      your radio suddenly went silent or the backlight display 
      doesn't work any more, then turn these knobs clockwise 
      to increase volume and backlight brightness.

      Also, these values could be defined not as Global Functions,
      but under the MODELS: Special Functions Table where they would
      apply only to that model... which might make more sense.
      However, in my case I fly only on Quadcopter so for the 
      moment I defined these tracks to play across all models.
      In the future, obviously, if I want to fly a wing, or a
      simulator with different key assignments, I'd want to move
      them into Special Functions per each model.




             __.....__
          .'" _  o    "`.
        .' O (_)     () o`.
       .           O       .
      . ()   o__...__    O  .
     . _.--"""       """--._ .
     :"                     ";
      `-.__    :   :    __.-'
           """-:   :-"""
              J     L
              :     :
             J       L
             :       :
             `._____.'
  _____                   _      __   __      ____
 / ___/__  ___  __ ______(_)__ _/ /  / /_____/ __/______ ___
/ /__/ _ \/ _ \/ // / __/ / _ `/ _ \/ __/___/ _// __/ -_) -_)
\___/\___/ .__/\_, /_/ /_/\_, /_//_/\__/   /_/ /_/  \__/\__/
        /_/   /___/      /___/
 ==============================================================================
 4. == Copyright Free License Blurb == == == == ==


    These sound files are free as in free beer, or free air.
    You are free to copy it, modify it, change it,
    delete it, sell it, blow it up, bundle it with your
    products as a value added freebee, bundle it with
    your software or hardware, use it in Youtube videos,
    host it on your own web server, whatever you want.

    Basically, its released with with the GNU Public License or GPL.

    I only request that you attribute them as made
    by Choppergirl, but you do not have to explicitly
    do so, if you leave this Read Me file included and intact.



                                                   ,_  .--.
                                             , ,   _)\/    ;--.
                                     . ' .    \_\-'   |  .'    \
                                    -= * =-   (.-,   /  /       |
                                     ' .\'    ).  ))/ .'   _/\ /
                                         \_   \_  /( /     \ /(
                                         /_\ .--'   `-.    //  \
                                         ||\/        , '._//    |
                                         ||/ /`(_ (_,;`-._/     /
                                         \_.'   )   /`\       .'
                                              .' .  |  ;.   /`
                                             /      |\(  `.(
                                            |   |/  | `    `
                                            |   |  /
                                            |   |.'
                                         __/'  /
                                     _ .'  _.-`
                                  _.` `.-;`/
                                 /_.-'` / /
                                       | /
                                      ( /
                                     /_/
   ___                      ___               ___                        __
  / _ \___ _______  _______/ (_)__  ___ _____/ _ \___ ___ ___ _____ ___ / /____
 / , _/ -_) __/ _ \/ __/ _  / / _ \/ _ `/___/ , _/ -_) _ `/ // / -_|_-</ __(_-<
/_/|_|\__/\__/\___/_/  \_,_/_/_//_/\_, /   /_/|_|\__/\_, /\_,_/\__/___/\__/___/
                                  /___/               /_/
 ==============================================================================
 5. == Sound File Recording Requests == == == == ==

     If you need a custom Hello or Goodbye sound file, or any custom
     sound files not present, hit me up with an email.   If I am still
     alive and kicking and in a capacity to do so, I maybe be able to
     reply to you with the requested custom recorded sound files.

     If I deem them generic enough and potentially useful for others,
     I may include them in future releases.

     Some hard to pronounce names or foreign words I may request you
     send me an audio file of how you say them, if I can't get it right.
     I'll try to listen to them first though with Google Translate.

     Also, if you can think up a whole bunch of files that would be useful
     for an RC hobby to include, that is not flying related... to expand
     the sound pack with, such as recordings that would be useful for
     cars/boating/submarines/whatever, make a list, shoot it too me.



     I don't suspect at this point I will recording a sound pack for
     any language other than English.. but.. you never know.  If there
     is a demand out there, let me know.




                              .--.   _,
                          .--;    \ /(_
                         /    '.   |   '-._    . ' .
                        |       \  \    ,-.)  -= * =-
                         \ /\_   '. \((` .(    '/. '
                          )\ /     \ )\  _/   _/
                         /  \\    .-'   '--. /_\
                        |    \\_.' ,        \/||
                        \     \_.-';,_) _)'\ \||
                         '.       /`\   (   '._/
                           `\   .;  |  . '.
                             ).'  )/|      \
                             `    ` |  \|   |
                                     \  |   |
                                      '.|   |
                                         \  '\__
                                          `-._  '. _
                                             \`;-.` `._
                                              \ \ `'-._\
                                               \ |
                                                \ )
                                                 \_\
   ____     __                   ___  __
  / __/_ __/ /___ _________ ____/ _ \/ /__ ____  ___
 / _// // / __/ // / __/ -_)___/ ___/ / _ `/ _ \(_-<
/_/  \_,_/\__/\_,_/_/  \__/   /_/  /_/\_,_/_//_/___/
 ==============================================================================
 6. == Future Plans == == == == ==


   Edgy Cheeky Plus Pack

     So, it seems everybody has this second/third/fourth old transmitter
     that they don't use any more, but they hang on to it for
     sentimentality's sake.

     I was thinking, what if you could keep it the way it was, but also
     via a LUA script give it a new fun job and give you a reason to take
     it with you when you go flying or to flying meets?

     So this is what I'm thinking.. I record a whole bunch of peanut gallery
     style commentary, and release it as a Cheeky Plus Pack you can install
     in addition to my standard basic Edgy Sound Pack.

     You install it on your used TX, or even your main TX, and when you
     want some cheeky commentary, you fire up the included LUA script, and
     it plays a random peanut gallery comment out loud...   to a random
     interval, or set interval, or to a button press or switch flip.

     You can play with it in a lazy boy chair, or set it down next to you
     while flying, or set it on a table running all to itself as an
     attraction geter.

     For a inkling of what some of the sayings might be like, check
     out my Cheapskate Flyer magazine covers here:

     http://air-war.org/cheapskate.shtml

     I would divide up the commentary into three different categories of
     sayings...   Positive, Neutral, and Negative...  so that if you
     chose you could bind a switch and momentary button to at your
     command, run a LUA script that depending on your switch setting,
     would reply with either an Affirmative, Neutral, or Negative
     comment when you pressed the momentary switch.

     Why so?  Because if you were lazy,and someone asked you a question,
     you could flip the switch to the Positive, Neutral, or Negative
     position and press the momentary button to give them a snarky
     little response... said by your transmitter, of course.  Why ever
     talk again!?   I've tried this in practice with my own TX, and
     it's particularly fun as a backseat passenger in a car, esp. now
     that we have a way to bind volume to the S1 pot.

     I have a long list of snarky, pugnacious, edgy, and cheeky sayings
     as candidates to record...  but haven't written any LUA scripts
     and I don't even know yet if they could be bound to run off a
     switch (I assume so, der).   I'm a Python programmer, and hate LUA,
     so if anyone out there fluent in LUA would be interested in
     writing some code to do these things, hit me up with an email.


   Backseat Driver

     Another idea would be a LUA script that analyzed your Crossfire
     telemetry during a flight... for example... GPS ground speed, Altitude,
     Pitch, Roll, Yaw, RSSI signal strength, etc...  and provided
     sporadic background commentary based up on that.  Not so often, mind you,
     that it became annoying, but just enough to give a bit more
     personalization and personality to your radio

   Video games

     It might be possible to port or write some LUA script video games
     playable on your TX color screen... particularly when the touch screen
     gets implemented, but not necessisarily necessary as there are plenty
     of control inputs accessible already.  Ms. Pacman to a Joystick, anyone?
     Tetris?  Pinball?  Hangman?  Wheel of Forturen?  Slots?  Card games?
     Trivial  Pursuit?






                       ------
                       | |(A)\                                      |
                       | ____ \_________|----^"|"""""|"\___________ |
              .         \___\  stay edgy >>   `""""""""     =====  "|D
                              ^^-------____--""""""""""+""--_  __--"|
              |	                          `""|"-->####)+---|`""     |
              |                                         \  \
     .               /                                 <- O -)
      \       I                                          `"'
                  /
        \  ,g88R_
          d888(`  ).                   _
 -  --==  888(     ).=--           .+(`  )`.
          Y8P(       '`.          :(   .    )
        .+(`(      .   )     .--  `.  (    ) )
       ((    (..__.:'-'   .=(   )   ` _`  ) )
`.     `(       ) )       (   .  )     (   )  ._
  )      ` __.:'   )     (   (   ))     `-'.:(`  )
)  )  ( )       --'       `- __.'         :(      ))
.-'  (_.'          .')                    `(    )  ))
                  (_  )                     ` __.:'


  _____          __           __
 / ___/__  ___  / /____ _____/ /_
/ /__/ _ \/ _ \/ __/ _ `/ __/ __/
\___/\___/_//_/\__/\_,_/\__/\__/
 ==============================================================================
 7. == Who to contact with feedback/ requests == == == == ==

     This sound pack is make by me, Choppergirl, and I release it freely into 
     the Public Domain under the GNU Public License (GPL).

     You can direct your hate mail, bug reports, suggestions, improvements,
     requests for me to record additional sound files, etc..

     To contact me, put "Sound Pack" in the Subject somwhere if you email me.


     Email me at:  choppergirl@air-war.org

     Home Page: http://choppergirl.air-war.org

     Quadopter FPV / RC Page:  http://fpv.air-war.org

     Youtube:  http://youtube.com/choppergirl

     If you visit my Youtube channel, subscribe! :-)

     Happy flying, 
     and watch your six, 
     because I'm on it...
                                                           .-""-.
                                                          (___/\ \
                                       ,                 (|^ ^ ) )
                                      /(                _)_\=_/  (
                                  ,..__/ `\          ____(_/_ ` \   )
                                   `\    _/        _/---._/(_)_  `\ (
                                    '--\ `-.__..-'    /.    (_), |  )
                                        `._        ___\_____.'_| |__/
                                         `~----"`   `-.........'
      _ /       _ _ _ '_ /
     ( /)()/)/)(-/ (/// (                         dream up something wilder
          / /     _/

     choppergirl@air-war.org                     choppergirl's flying circus

     May 1, 2021                                      don't just fly

     http://air-war.org                              frolic in the sky




                                      *****
  *(((##                              @@@@#                               ##(((*
 .##,,***//%%%%&&,( /*               @@@@##                // ,/&&%%%%//***,,##
   *****///%%%%%%%%%(#*.,.         *@@@@#//.           ,../#%%%%%%%%%#///*****
   /////////###,&%%/%%%**((/(////,,(#(@@/*#(%*,*////(///**%%%#%%%,###****/////
    ##((///** %%%#%%#%%/##%###..,/*@/%@@##%(//*(/.*#%#%###%%*%%##%% **//(((##
      ##(//**.(/*.%#%%,((#((((#(##(##////**/(#(##(#((((#((*%#%% //(,**/((##
          #(/*,(/*.(*.//(//(/(//(/(/(%@@@&/((/(//@@&&(//(//,/(.*/(,*/(#
             *** (/,*/*/**/*/**/*////(@@@%/*/(#@/%&&/*/**/**,,/# **,
                                    &@@@@@/,(@#/@&/
                                    /@/#((/#@@@#/%@@(@
                                     /@/#((/#@@@#/%@@(@
           ||                 
   ....   ...  ... ..    ... ... ...  ....   ... ..      ...   ... ..    ... .
  '' .||   ||   ||' ''    ||  ||  |  '' .||   ||' ''   .|  '|.  ||' ''  || ||
  .|' ||   ||   ||    |||  ||| |||   .|' ||   ||       ||   ||  ||       |''
  '|..'|' .||. .||.         |   |    '|..'|' .||.  ||  '|..|'  .||.     '||||.
---------------------------------------------------------------------  .|....'
                    the sky is a commons for everyone to enjoy














                                     .'\   /`.
                                   .'.-.`-'.-.`.
                              ..._:   .-. .-.   :_...
                            .'    '-.(o ) (o ).-'    `.
                           :  _    _ _`~(_)~`_ _    _  :
                          :  /:   ' .-=_   _=-. `   ;\  :
                          :   :|-.._  '     `  _..-|:   :
                           :   `:| |`:-:-.-:-:'| |:'   :
                            `.   `.| | | | | | |.'   .'
                              `.   `-:_| | |_:-'   .'
                               `-._   ````    _.-'
		 the universe pivots on the statically improbable
		     becoming a done fact and ancient history
                      Why, sometimes I've believed as many as
                      six impossible things before breakfast.